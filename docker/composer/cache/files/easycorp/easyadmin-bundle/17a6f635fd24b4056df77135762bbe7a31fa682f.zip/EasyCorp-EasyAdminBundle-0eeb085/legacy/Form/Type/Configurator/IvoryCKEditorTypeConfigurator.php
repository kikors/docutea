<?php

namespace JavierEguiluz\Bundle\EasyAdminBundle\Form\Type\Configurator;

@trigger_error('The '.__NAMESPACE__.'\IvoryCKEditorTypeConfigurator class is deprecated since version 1.16 and will be removed in 2.0. Use the EasyCorp\Bundle\EasyAdminBundle\Form\Type\Configurator\IvoryCKEditorTypeConfigurator class instead.', E_USER_DEPRECATED);

class_exists('EasyCorp\Bundle\EasyAdminBundle\Form\Type\Configurator\IvoryCKEditorTypeConfigurator');

if (\false) {
    class IvoryCKEditorTypeConfigurator implements TypeConfiguratorInterface
    {
    }
}
