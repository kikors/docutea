EasyAdmin
=========

EasyAdmin creates administration backends for your Symfony applications with
unprecedented simplicity.

-----

# ⚠️
# This is the 1.x branch of EasyAdmin, which is NO LONGER MAINTAINED.
# EasyAdmin 1.x should only be used in legacy projects that can't be upgraded to newer EasyAdmin versions.
