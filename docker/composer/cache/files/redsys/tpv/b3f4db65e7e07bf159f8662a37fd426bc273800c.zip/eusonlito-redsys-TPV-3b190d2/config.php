<?php
return array(
    'Environment' => 'test', // Puedes indicar test o real
    'MerchantCode' => '1234567890',
    'Key' => 'sq7HjrUOBfKmC576ILgskD5srU870gJ7',
    'Terminal' => '1',
    'TransactionType' => '0',
    'Currency' => '978',
    'MerchantName' => 'COMERCIO',
    'Titular' => 'Mi Comercio',
    'ConsumerLanguage' => '001',
    'SignatureVersion' => 'HMAC_SHA256_V1'
);
